import React, { useState } from "react"
import "./login.css"
import VR_IMG from '../../images/vr.jpg';
import axios from "axios"
import { useHistory } from  "react-router-dom";

const Login = () => {
    const [user, setUser] = useState({
        email: "",
        password: "",
        type : ""
    })

    const handle_change = e => {
        const { name, value } = e.target
        if(e.target.value == "0"){
            user.type="Admin";
        }
        else{
            user.type="User";
        }

        setUser({
            ...user,
            [name]: value
        })
    }

    const go_to_login = () => {
        axios.post("http://localhost:1337/api/login", user)
        .then((response) => {
            console.log(response.data.message);
        });
    }

    const check_values = () => {
        // directly check in user object 
        let emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        
        if (user.email.trim().length == 0 || !emailPattern.test(user.email)) {
            document.getElementById("error_msg").innerHTML = "Invalid email";
            return;
        }
        
        if(user.password.trim().length == 0 || user.password.indexOf(' ') >= 0){
            document.getElementById("error_msg").innerHTML = "Invalid Password";
            return;
        }

        // all are correct -> call login api
        go_to_login();
    }

    return (
        <div className="login_page">
            {console.log("User", user)}
            <h1 style={{textAlign:"center"}}>~ Login ~</h1>

            <div className="flex-container">
                <div className="flex-child">
                    <img src={VR_IMG} id="vr_logo"/>
                    <div id="about_vreqst">
                        <h2>About VREQST Tool</h2>
                        OUR SSD Project is JSON Validator<br/>
                        Our mentor is Sai Anirudh Karri
                    </div>
                </div>

                <div className="flex-child login_input">
                    <div id="error_msg"></div>
                    
                    <div id="login_box">
                        <input type="text" name = "email" placeholder = "Email ID" value ={user.email} onChange = {handle_change}/>
                        <br/><br/>
                        <input type="password" name="password" placeholder="Password" value={user.password} onChange = {handle_change}/>
                        <br/><br/>
                        <select name="u_type" onChange={handle_change}>
                            <option value="0">Admin</option>
                            <option value="1">User</option>
                        </select>
                        <br/><br/>
                        <button type="button" onClick={check_values}>
                            <span className="glyphicon glyphicon-log-in"></span> Login
                        </button>
                    </div>
                    <br/><br/>

                    <div id="registration_desk">
                        <p>
                            For new users - <a href='./register' id="redirect_to_registration">Register here</a>
                        </p>
                    </div>
                </div>
                
            </div>
        </div>
    )
}

export default Login